package Notification;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class News 
{
	WebDriver wd;
	@Test
	public void f() 
	{
		wd.findElement(By.linkText("NEWS")).click();
		JavascriptExecutor js = (JavascriptExecutor) wd;
		js.executeScript("window.scrollBy(0,500)", "");
		wd.findElement(By.xpath("/html[1]/body[1]/div[6]/div[1]/div[27]/div[1]/form[1]/input[1]")).sendKeys("sanketsathe1307@rediffmail.com");
		wd.findElement(By.id("subscribe_btn_in")).click();
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.rediff.com/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
