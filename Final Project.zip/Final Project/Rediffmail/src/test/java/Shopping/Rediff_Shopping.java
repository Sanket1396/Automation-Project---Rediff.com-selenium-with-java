package Shopping;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Rediff_Shopping 
{
	WebDriver wd;
	@Test
	public void f() throws InterruptedException 
	{
		WebElement sh=wd.findElement(By.linkText("Shopping"));
		sh.click();
		WebElement mob=wd.findElement(By.linkText("Mobiles"));
		mob.click();
		WebElement cell=wd.findElement(By.linkText("Sking S500 4G With Dual Sim 2GB Ram 5MP Camera 3000 mah Battery And 5 inches(12.7 cm) Display"));
		cell.click();
		JavascriptExecutor js = (JavascriptExecutor) wd;
		js.executeScript("window.scrollBy(0,350)", "");
		WebElement details=wd.findElement(By.id("desc_plusicon"));
		details.click();
		js.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(3000);
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.rediff.com/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
