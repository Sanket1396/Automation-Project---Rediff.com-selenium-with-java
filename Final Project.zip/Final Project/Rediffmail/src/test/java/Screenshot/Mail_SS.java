package Screenshot;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Mail_SS 
{
	WebDriver wd;
	@Test
	public void f() throws IOException, InterruptedException 
	{
		
		wd.findElement(By.linkText("Sign in")).click();

		wd.findElement(By.name("login")).sendKeys("sanketsathe1307@rediffmail.com");
		
		wd.findElement(By.name("passwd")).sendKeys("Rediff@1307");

		wd.findElement(By.name("proceed")).click();
		
		Thread.sleep(2000);
		
		wd.findElement(By.xpath("/html[1]/body[1]/div[4]/div[2]/div[2]/div[2]/div[2]/ul[2]/li[1]/div[1]/div[1]/ul[1]/li[1]/span[1]")).click();
		
		File ss=((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(ss, new File("F:\\inbox.png"));
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.rediff.com/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
