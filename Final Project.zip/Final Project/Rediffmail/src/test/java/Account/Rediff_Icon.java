package Account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Rediff_Icon 
{
	WebDriver wd;
	@Test
	public void f() throws InterruptedException 
	{
		wd.findElement(By.linkText("Rediffmail")).click();
		
		wd.findElement(By.name("login")).sendKeys("sanketsathe1307@rediffmail.com");

		wd.findElement(By.name("passwd")).sendKeys("Rediff@1307");

		wd.findElement(By.name("proceed")).click();
	
		Thread.sleep(2000);
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.rediff.com/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
