package Account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Rediff_Profile 
{
	WebDriver wd;
	@Test
	public void f() throws InterruptedException 
	{
		wd.findElement(By.id("txtlogin")).sendKeys("sanketsathe1307@rediffmail.com");

		wd.findElement(By.id("pass_box")).sendKeys("Rediff@1307");

		wd.findElement(By.xpath("/html[1]/body[1]/div[3]/div[5]/div[1]/form[1]/div[2]/input[3]")).click();

		wd.findElement(By.linkText("Sanket Sanjay")).click();

		WebElement upload=wd.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[6]/form[1]/table[1]/tbody[1]/tr[1]/td[2]/input[1]"));
		upload.sendKeys("E:\\Sanket Gallery\\PhotoShoot");
		Thread.sleep(3000);

		Thread.sleep(2000);
		wd.findElement(By.id("cld_companyname")).sendKeys("EduBridge");
		Thread.sleep(2000);
		wd.findElement(By.id("cld_school")).sendKeys("Camp Education");
		Thread.sleep(2000);
		wd.findElement(By.id("cld_college")).sendKeys("Dy Patil");
		Thread.sleep(2000);
		wd.findElement(By.id("cld_savebtn")).click();
		Thread.sleep(2000);
		
		
		wd.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[7]/span[4]")).click();
		wd.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[8]/span[4]")).click();
		wd.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[8]/div[1]/p[2]/span[1]")).click();
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://mypage.rediff.com/login/dologin");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
