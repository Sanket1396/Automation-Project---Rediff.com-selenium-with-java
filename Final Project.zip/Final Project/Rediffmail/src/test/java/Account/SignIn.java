package Account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class SignIn 
{
	WebDriver wd;
	@Test
	public void f() throws IOException, InterruptedException 
	{
		//for referring the file we want to open
		File f=new File("InputFile\\Sign.xlsx");

		//for opening the file in read mode
		FileInputStream fis=new FileInputStream(f);

		XSSFWorkbook wk=new XSSFWorkbook(fis);

		//for referring the sheet we want to read
		XSSFSheet sh= wk.getSheet("Sheet1");

		int size1= sh.getLastRowNum();	// last index of sheet 1
		System.out.println("No. of records are"+size1);

		for (int i=1;i<=size1;i++)
		{
			String u=sh.getRow(i).getCell(0).toString();
			String p=sh.getRow(i).getCell(1).toString();
			System.out.println(u+"     |     "+p);

			wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			wd.findElement(By.linkText("Sign in")).click();

			WebElement un=wd.findElement(By.name("login"));
			un.sendKeys(u);
			Thread.sleep(2000);

			WebElement pw=wd.findElement(By.name("passwd"));
			pw.sendKeys(p);
			Thread.sleep(2000);

			wd.findElement(By.name("proceed")).click();
			Thread.sleep(2000);
			try
			{
				wd.findElement(By.linkText("Logout")).click();
				wd.findElement(By.linkText("Rediff Home")).click();
			}
			catch (Exception e)
			{
				System.out.println("Wrong Username and Password Exception");
				wd.findElement(By.linkText("rediff.com")).click();
			}
			
		}
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.rediff.com/");
	}
	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}