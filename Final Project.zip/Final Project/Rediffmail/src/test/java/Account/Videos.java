package Account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Videos 
{
	WebDriver wd;
	@Test
	public void f() throws InterruptedException 
	{
		wd.findElement(By.linkText("Videos")).click();
		wd.findElement(By.linkText("Upload Videos")).click();
		wd.findElement(By.id("txtlogin")).sendKeys("sanketsathe1307@rediffmail.com");
		wd.findElement(By.id("btn_go")).click();
		Thread.sleep(3000);
		wd.findElement(By.name("num")).sendKeys("Rediff@1307");
		Thread.sleep(3000);
		wd.findElement(By.xpath("/html[1]/body[1]/div[3]/div[4]/div[1]/form[1]/div[2]/input[3]")).submit();
		Thread.sleep(3000);
		wd.findElement(By.xpath("/html[1]/body[1]/div[2]/form[1]/div[1]/div[1]/span[1]/input[1]")).sendKeys("F:\\Sanket\\Tuffy.mp4");
		Thread.sleep(15000);
		//wd.findElement(By.linkText("Cancel upload")).click();
		//Thread.sleep(2000);
		wd.findElement(By.xpath("/html[1]/body[1]/div[2]/form[1]/table[1]/tbody[1]/tr[1]/td[2]/form[1]/div[1]/div[1]/div[2]/div[2]/span[1]/input[1]")).click();
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.rediff.com/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
