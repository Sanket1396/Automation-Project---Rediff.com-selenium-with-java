package Account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class ComposeMail 
{
	WebDriver wd;
	@Test
	public void f() throws IOException, InterruptedException 
	{
		//for referring the file we want to open
		File f=new File("InputFile\\Sign.xlsx");

		//for opening the file in read mode
		FileInputStream fis=new FileInputStream(f);

		XSSFWorkbook wk=new XSSFWorkbook(fis);

		//for referring the sheet we want to read
		XSSFSheet sh= wk.getSheet("Sheet2");

		int size1= sh.getLastRowNum();	// last index of sheet 1
		System.out.println("No. of records are"+size1);
		WebElement wm=wd.findElement(By.linkText("Write mail"));
		wm.click();

		for (int i=1;i<=size1;i++)
		{
			
			String to=sh.getRow(i).getCell(0).toString();
			String sub=sh.getRow(i).getCell(1).toString();
			String comp=sh.getRow(i).getCell(2).toString();	
			
			System.out.println(to+ " |  " + sub + " | " + comp);

			Thread.sleep(2000);
			
			List<WebElement> frames=wd.findElements(By.tagName("iframe"));
			System.out.println("No. of frames are: " +frames.size());
			

			wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			WebElement t=wd.findElement(By.id("TO_IDcmp2"));
			t.clear();
			t.sendKeys(to);

			WebElement su=wd.findElement(By.xpath("//body/div[4]/div[2]/div[2]/div[2]/div[2]/ul[2]/li[2]/div[1]/div[1]/ul[1]/li[4]/input[1]"));
			su.sendKeys(sub);
			

			wd.switchTo().frame(2);
			WebElement com=wd.findElement(By.xpath("/html[1]/body[1]"));
			com.sendKeys(comp);
			
			// code for send
			
			Thread.sleep(3000);
			wd.switchTo().parentFrame();
			
			wd.findElement(By.linkText("Send")).click();
			Thread.sleep(2000);
			wd.findElement(By.linkText("Write mail")).click();
		}

	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.rediff.com/");
		wd.findElement(By.linkText("Sign in")).click();
		wd.findElement(By.name("login")).sendKeys("sanketsathe1307@rediffmail.com");
		wd.findElement(By.name("passwd")).sendKeys("Rediff@1307");
		wd.findElement(By.name("proceed")).click();

	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
